#!/bin/sh
cc -o hello_O1 -O1 hello.c -lm
cc -o hello_O3 -O3 hello.c -lm
ar r hello.ar hello_O1 hello_O3
tar cvf hello.tar hello.ar hello.c make.sh
